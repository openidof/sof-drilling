package models

case class Person(
    firstName: String,
    quest: String,
    favoriteColor: String
)
