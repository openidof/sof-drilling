package org.sample.util;

public class BuiltBy {
    public static String watermark(String input) {
        return input + " (built by Gradle)";
    }
}
