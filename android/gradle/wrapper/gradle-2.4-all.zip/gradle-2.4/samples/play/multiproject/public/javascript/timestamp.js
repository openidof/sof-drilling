function updateTimestamp() {
    document.getElementById("timestamp").innerHTML = new Date();
}
window.onload=updateTimestamp;
