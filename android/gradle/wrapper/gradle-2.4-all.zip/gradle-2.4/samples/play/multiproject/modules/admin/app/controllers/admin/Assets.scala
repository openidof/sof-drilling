package controllers.admin

object Assets extends controllers.AssetsBuilder {
}
