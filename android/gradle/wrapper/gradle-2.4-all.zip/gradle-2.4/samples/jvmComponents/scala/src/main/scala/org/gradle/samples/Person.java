package org.gradle.samples;

import java.lang.String;

public class Person{
    String name;

    public Person(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
