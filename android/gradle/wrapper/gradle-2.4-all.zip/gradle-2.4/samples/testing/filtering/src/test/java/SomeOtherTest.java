import org.junit.*;

public class SomeOtherTest {
    @Test public void quickUiCheck() {}
    @Test public void quickServerCheck() {}
}
