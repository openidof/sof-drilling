import org.junit.*;

public class SomeIntegTest {
    @Test public void test1() {}
    @Test public void test2() {}
}
