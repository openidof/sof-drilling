package org.gradle.testng;

public interface User
{
    String getFirstName();

    String getLastName();
}
