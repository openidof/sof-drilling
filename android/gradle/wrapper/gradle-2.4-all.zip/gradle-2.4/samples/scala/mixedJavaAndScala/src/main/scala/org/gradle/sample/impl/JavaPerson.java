package org.gradle.sample.impl;

public class JavaPerson extends PersonImpl {
    public JavaPerson(String name) {
        super(name);
    }
}
