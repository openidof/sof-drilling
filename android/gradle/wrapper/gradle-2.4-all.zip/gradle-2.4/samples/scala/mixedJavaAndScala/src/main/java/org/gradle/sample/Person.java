package org.gradle.sample;

public interface Person {
    String getName();
}
