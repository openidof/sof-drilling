package org.gradle;

public class MyClassTest extends junit.framework.TestCase {
    public void testDoSomething() throws Exception {
        new MyClass().doSomething();
    }
}
