To demonstrate the integration with prebuilt libraries available on the file system, this 'util' library must first be
built. The fact that it is built by Gradle is not important to this example.
