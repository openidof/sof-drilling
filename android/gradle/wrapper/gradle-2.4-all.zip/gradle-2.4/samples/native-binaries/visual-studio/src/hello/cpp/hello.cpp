#include <iostream>
#include "hello.h"

void LIB_FUNC hello () {
  std::cout << "Hello world!" << std::endl;
}
