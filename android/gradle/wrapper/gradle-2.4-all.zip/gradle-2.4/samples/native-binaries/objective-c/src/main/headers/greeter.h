#import <Foundation/Foundation.h>

@interface Greeter : NSObject
    - (void)sayHello;
@end
