#define IDS_HELLO    111
