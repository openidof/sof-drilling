class Sample {
}
