# Chapter 1 - Intoduction

## Hello World

This is a hello world example:

    task hello << {
        println 'Hello World!'
    }
