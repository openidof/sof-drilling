public class SomeClass {}
