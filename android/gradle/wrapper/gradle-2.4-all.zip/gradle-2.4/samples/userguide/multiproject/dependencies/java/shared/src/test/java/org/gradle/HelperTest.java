package org.gradle;

import org.junit.Test;

public class HelperTest {
    @Test
    public void ok() {
    }
}
