package org.gradle.sample.api;

public interface Person {
    String getFirstname();
    String getSurname();
}
