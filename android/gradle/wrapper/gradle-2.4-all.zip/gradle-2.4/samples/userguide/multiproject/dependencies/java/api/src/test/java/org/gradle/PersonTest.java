package org.gradle;

import org.junit.Test;

public class PersonTest {
    @Test
    public void ok() {
    }
}
