package org.gradle.sample.shared;

public class Helper {
    public static String prettyPrint(String text) {
       return "*** " + text + " ***";
    }
}

