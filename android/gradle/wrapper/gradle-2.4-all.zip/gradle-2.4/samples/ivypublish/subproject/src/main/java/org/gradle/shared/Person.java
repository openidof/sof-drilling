package org.gradle.shared;

public class Person {
    private String name;
}
