package org.gradle;

public class SomeClass {
}
