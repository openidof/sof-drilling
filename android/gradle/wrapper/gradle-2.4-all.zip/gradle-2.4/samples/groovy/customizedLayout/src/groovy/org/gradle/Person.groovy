package org.gradle

class Person {
    String name
}
