public class ExcludeGroovyJava {

}
