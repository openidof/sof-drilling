class ExcludeGroovy {

}
