package org.gradle;

public class JavaPerson extends GroovyPerson {
    public JavaPerson(String name) {
        setName(name);
    }
}
